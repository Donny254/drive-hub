const l=s=>{const o=s.split(/\r?\n/).filter(e=>e.trim().length>0);if(o.length===0)return[];const c=o[0].split(",").map(e=>e.trim());return o.slice(1).map(e=>{const n=e.split(",").map(t=>t.trim()),r={};return c.forEach((t,i)=>{r[t]=n[i]??""}),r})},a=(s,o)=>{const c=r=>{if(r==null)return"";const t=String(r);return t.includes(",")||t.includes('"')||t.includes(`
`)?`"${t.replace(/"/g,'""')}"`:t},e=o.join(","),n=s.map(r=>o.map(t=>c(r[t]??"")).join(",")).join(`
`);return`${e}
${n}`},d=(s,o)=>{const c=new Blob([o],{type:"text/csv;charset=utf-8;"}),e=URL.createObjectURL(c),n=document.createElement("a");n.href=e,n.setAttribute("download",s),document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(e)};export{d,l as p,a as t};
