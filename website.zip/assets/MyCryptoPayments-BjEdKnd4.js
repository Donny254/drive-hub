import{r as l,j as t}from"./framework-vendor-ByAaOVdP.js";import{A as ie}from"./AccountLayout-E8yqED8u.js";import{u as de,C as ce}from"./useCryptoPaymentStatus-CPJCeoMZ.js";import{D as B}from"./DatePickerField-Dio_OIki.js";import{u as pe,a as U,b as g,B as x}from"./index-DjkiYFh0.js";import{B as _}from"./badge-Cm_IPI86.js";import{C as y,c as f,a as me,b as ue}from"./card-gMmo9NpN.js";import{D as he,a as xe,b as ge,c as ye,d as fe}from"./dialog-Pif1LSO7.js";import{I as ve,L as K}from"./label-PdSRJPSP.js";import{t as be,d as we}from"./csv-DWdVleXq.js";import{t as je}from"./date-D4whknsD.js";import{E as Ne,f as M,d as Se}from"./pdfBranding-Bo-GzW_X.js";import{E as Ce}from"./EmptyState-DTXDhpbx.js";import{C as $e}from"./ticket-CstLxe-2.js";import"./Navbar-B0OkjCUp.js";import"./ui-vendor-BdudbMeF.js";import"./car-AQwnShEy.js";import"./shopping-bag-ZfKY-IBb.js";import"./wrench-DrGdAt1h.js";import"./crypto-79see229.js";import"./popover-D7eerFEH.js";import"./chevron-left-DNrmqleP.js";import"./chevron-right-BDpkUtnM.js";import"./query-vendor-DLWESmxy.js";const C=i=>new Intl.NumberFormat("en-KE",{style:"currency",currency:"KES",maximumFractionDigits:0}).format(i/100),ke=i=>{switch(i){case"paid":return"default";case"pending":return"secondary";case"failed":return"destructive";default:return"outline"}},Pe=i=>i==="crypto"?"secondary":i==="mpesa"?"default":"outline",Ze=()=>{const{token:i}=pe(),$=l.useMemo(()=>i?{Authorization:`Bearer ${i}`}:{},[i]),[u,O]=l.useState([]),[N,I]=l.useState(!0),[z,E]=l.useState(null),[d,R]=l.useState(null);l.useRef(null);const[S,F]=l.useState("all"),[A,W]=l.useState("all"),[D,H]=l.useState(""),[q,V]=l.useState(""),[v,G]=l.useState(null),[w,Q]=l.useState(null);l.useEffect(()=>{const e=setTimeout(()=>V(D),300);return()=>clearTimeout(e)},[D]);const J=l.useMemo(()=>{if(!d)return null;switch(d.kind){case"order":return`/api/payments/crypto/status/${d.id}`;case"booking":return`/api/payments/crypto/booking-status/${d.id}`;case"event_registration":return`/api/payments/crypto/event-registration-status/${d.id}`;default:return null}},[d]),{data:j,loading:L,error:X,refresh:Y}=de(J,!!d,5e3,$),k=l.useCallback(async e=>{if(!i)return;I(!0),E(null);const s=(n,a)=>{const p=String(a.paymentMethod||a.payment_method||"").trim()||"manual",h=String(a.paymentStatus||a.payment_status||"unpaid"),P=n==="order"?`Order ${String(a.id||"").slice(0,8)}`:String(n==="booking"?a.listingTitle||a.listing_title||`Booking ${String(a.id||"").slice(0,8)}`:a.eventTitle||a.event_title||`Event registration ${String(a.id||"").slice(0,8)}`),T=n==="order"?`${Number(a.itemsCount||a.items_count||0)} items`:n==="booking"?`${a.startDate||a.start_date||"--"} to ${a.endDate||a.end_date||"--"}`:`${Number(a.tickets||1)} ticket${Number(a.tickets||1)===1?"":"s"}`;return{kind:n,id:String(a.id||""),title:P,subtitle:T,amountCents:Number(a.totalCents||a.total_cents||a.amountCents||a.amount_cents||0),paymentMethod:p,paymentStatus:h,cryptoReviewNotes:String(a.cryptoReviewNotes||a.crypto_review_notes||"")||null,createdAt:String(a.createdAt||a.created_at||"")}},r=[["order","/api/orders"],["booking","/api/bookings"],["event_registration","/api/event-registrations"]],c=await Promise.allSettled(r.map(async([n,a])=>{const p=await U(a,{headers:$,signal:e});if(!p.ok)throw new Error(`Failed to load ${n.replaceAll("_"," ")} payments`);const h=await p.json();return(Array.isArray(h)?h:h.data??[]).map(T=>s(n,T)).filter(Boolean)})),o=c.flatMap(n=>n.status==="fulfilled"?n.value:[]),m=c.filter(n=>n.status==="rejected");if(O(o.sort((n,a)=>a.createdAt.localeCompare(n.createdAt))),m.length>0){const n=m.map(a=>{var p;return a.status==="rejected"?((p=a.reason)==null?void 0:p.message)||"Load failed":""}).filter(Boolean).join(" • ");E(n||"Some crypto payments could not be loaded."),g.error(n||"Some crypto payments could not be loaded.")}e!=null&&e.aborted||I(!1)},[$,i]);l.useEffect(()=>{const e=new AbortController;return k(e.signal),()=>e.abort()},[k]);const Z=u.filter(e=>e.paymentStatus==="pending").length,ee=u.filter(e=>e.paymentStatus==="paid").length,te=u.filter(e=>e.paymentStatus==="failed").length,ae=u.filter(e=>e.paymentMethod==="crypto").length,se=u.filter(e=>e.paymentMethod==="mpesa").length,b=u.filter(e=>{const s=S==="all"?!0:e.paymentMethod===S,r=A==="all"?!0:e.paymentStatus===A,c=je(new Date(e.createdAt)),o=v&&w&&v>w?null:v,m=v&&w&&v>w?null:w,n=o?c>=o:!0,a=m?c<=m:!0,p=q.trim().toLowerCase(),h=p?[e.title,e.subtitle,e.paymentMethod,e.paymentStatus,e.cryptoReviewNotes].filter(Boolean).some(P=>String(P).toLowerCase().includes(p)):!0;return s&&r&&n&&a&&h}),ne=()=>{const e=be(b.map(s=>({type:s.kind.replaceAll("_"," "),title:s.title,subtitle:s.subtitle,payment_method:s.paymentMethod||"manual",status:s.paymentStatus,amount:s.amountCents/100,notes:s.cryptoReviewNotes||"--",created_at:s.createdAt})),["type","title","subtitle","payment_method","status","amount","notes","created_at"]);we(`payments-${new Date().toISOString().slice(0,10)}.csv`,e),g.success("Payments exported.")},re=async()=>{const e=new Ne({unit:"pt",format:"a4"}),s=40,r=e.internal.pageSize.getWidth(),c=r-s*2;let o=48;const m=await M(),n=a=>{o+a>e.internal.pageSize.getHeight()-s&&(e.addPage(),o=s)};e.setFillColor(7,19,27),e.rect(0,0,r,38,"F"),m&&e.addImage(m,Se(m),s,6,24,24),e.setFont("helvetica","bold"),e.setFontSize(18),e.setTextColor(255,255,255),e.text("WheelsnationKe",s+32,16),e.setFontSize(11),e.setFont("helvetica","normal"),e.text("Payments Center",s+32,28),e.text(`Generated: ${new Date().toLocaleString()}`,r-s,16,{align:"right"}),e.text(`Records: ${b.length}`,r-s,28,{align:"right"}),o=54,e.setTextColor(10,18,24),b.forEach((a,p)=>{n(88),e.setDrawColor(210,216,224),e.roundedRect(s,o,c,78,6,6),e.setFont("helvetica","bold"),e.setFontSize(12),e.text(`${p+1}. ${a.title}`,s+10,o+18),e.setFont("helvetica","normal"),e.setFontSize(10),e.text(`Type: ${a.kind.replaceAll("_"," ")}`,s+10,o+34),e.text(`Method: ${a.paymentMethod||"manual"}`,s+10,o+48),e.text(`Status: ${a.paymentStatus}`,s+10,o+62),e.text(`Amount: ${C(a.amountCents)}`,s+220,o+34),e.text(`Created: ${new Date(a.createdAt).toLocaleString()}`,s+220,o+48);const h=e.splitTextToSize(a.cryptoReviewNotes||"No review notes yet.",c-240);e.text(h,s+220,o+62),o+=92}),e.save(`payments-${new Date().toISOString().slice(0,10)}.pdf`),g.success("Payments PDF downloaded.")},oe=async e=>{const s=window.open("","_blank","noopener,noreferrer,width=900,height=700");if(!s){g.error("Unable to open print window.");return}const r=await M();s.document.write(`
      <html>
        <head>
          <title>Payment Summary</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 24px; color: #111; }
            .header { display: flex; align-items: center; gap: 14px; border-bottom: 2px solid #0f1f2a; padding-bottom: 14px; margin-bottom: 18px; }
            .logo { width: 56px; height: 56px; object-fit: contain; border: 1px solid #ddd; border-radius: 12px; background: #fff; padding: 6px; }
            h1 { margin: 0; }
            h2 { margin: 0; font-size: 18px; }
            .muted { color: #666; }
            .row { margin: 10px 0; }
            .label { font-weight: bold; display: inline-block; min-width: 160px; }
            .card { border: 1px solid #ddd; border-radius: 12px; padding: 16px; margin-top: 18px; }
          </style>
        </head>
        <body>
          <div class="header">
            ${r?`<img class="logo" src="${r}" alt="WheelsnationKe logo" />`:""}
            <div>
              <h1>WheelsnationKe</h1>
              <h2>Payment Summary</h2>
              <p class="muted">${e.title}</p>
            </div>
          </div>
          <div class="card">
            <div class="row"><span class="label">Type:</span> ${e.kind.replaceAll("_"," ")}</div>
            <div class="row"><span class="label">Method:</span> ${e.paymentMethod||"manual"}</div>
            <div class="row"><span class="label">Status:</span> ${e.paymentStatus}</div>
            <div class="row"><span class="label">Amount:</span> ${C(e.amountCents)}</div>
            <div class="row"><span class="label">Details:</span> ${e.subtitle}</div>
            <div class="row"><span class="label">Notes:</span> ${e.cryptoReviewNotes||"--"}</div>
            <div class="row"><span class="label">Created:</span> ${new Date(e.createdAt).toLocaleString()}</div>
          </div>
          <script>window.onload = () => window.print();<\/script>
        </body>
      </html>
    `),s.document.close(),g.success("Payment summary opened for printing.")},le=async e=>{if(e.kind!=="order"){await oe(e);return}try{const s=await U(`/api/orders/${e.id}`,{headers:$});if(!s.ok)throw new Error("Failed to load order invoice");const r=await s.json(),c=window.open("","_blank","noopener,noreferrer,width=900,height=700");if(!c){g.error("Unable to open print window.");return}const o=await M(),m=(r.items||[]).map(n=>`
            <tr>
              <td>${n.name}</td>
              <td>${n.quantity}</td>
              <td>${n.size||"--"}</td>
              <td>${C(n.priceCents)}</td>
              <td>${C(n.priceCents*n.quantity)}</td>
            </tr>
          `).join("");c.document.write(`
        <html>
          <head>
            <title>Order Invoice</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 24px; color: #111; }
              .header { display: flex; align-items: center; gap: 14px; border-bottom: 2px solid #0f1f2a; padding-bottom: 14px; margin-bottom: 18px; }
              .logo { width: 56px; height: 56px; object-fit: contain; border: 1px solid #ddd; border-radius: 12px; background: #fff; padding: 6px; }
              h1 { margin: 0; }
              h2 { margin: 0; font-size: 18px; }
              .muted { color: #666; }
              .row { margin: 10px 0; }
              .label { font-weight: bold; display: inline-block; min-width: 160px; }
              .card { border: 1px solid #ddd; border-radius: 12px; padding: 16px; margin-top: 18px; }
              table { width: 100%; border-collapse: collapse; margin-top: 16px; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 12px; }
              th { background: #f4f4f4; }
            </style>
          </head>
          <body>
            <div class="header">
              ${o?`<img class="logo" src="${o}" alt="WheelsnationKe logo" />`:""}
              <div>
                <h1>WheelsnationKe</h1>
                <h2>Order Invoice</h2>
                <p class="muted">Order ${r.id}</p>
              </div>
            </div>
            <div class="card">
              <div class="row"><span class="label">Status:</span> ${r.status}</div>
              <div class="row"><span class="label">Payment Method:</span> ${r.paymentMethod||"manual"}</div>
              <div class="row"><span class="label">Payment Status:</span> ${r.paymentStatus}</div>
              <div class="row"><span class="label">Paid At:</span> ${r.paidAt||"--"}</div>
              <div class="row"><span class="label">Created:</span> ${new Date(r.createdAt).toLocaleString()}</div>
            </div>
            <table>
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Qty</th>
                  <th>Size</th>
                  <th>Unit</th>
                  <th>Line Total</th>
                </tr>
              </thead>
              <tbody>${m}</tbody>
            </table>
            <div class="card">
              <div class="row"><span class="label">Total:</span> ${C(r.totalCents)}</div>
            </div>
            <script>window.onload = () => window.print();<\/script>
          </body>
        </html>
      `),c.document.close(),g.success("Order invoice opened for printing.")}catch(s){console.error(s),g.error("Unable to print invoice.")}};return t.jsx(ie,{title:"Crypto Payments",children:t.jsxs("div",{children:[t.jsxs("div",{className:"mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",children:[t.jsx("p",{className:"text-sm text-muted-foreground",children:"Track your M-Pesa and crypto-backed orders, bookings, and event registrations in one place."}),t.jsxs("div",{className:"flex flex-wrap gap-2",children:[t.jsx(x,{variant:"secondary",onClick:()=>void k(),disabled:N,children:N?"Refreshing...":"Refresh"}),t.jsx(x,{variant:"hero",onClick:ne,disabled:b.length===0,children:"Export CSV"}),t.jsx(x,{variant:"secondary",onClick:()=>void re(),disabled:b.length===0,children:"Download PDF"})]})]}),t.jsxs("div",{className:"mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4",children:[t.jsx(y,{className:"rounded-2xl",children:t.jsxs(f,{className:"p-5",children:[t.jsx("p",{className:"text-sm text-muted-foreground",children:"Total Payments"}),t.jsx("p",{className:"mt-2 text-3xl font-semibold",children:u.length})]})}),t.jsx(y,{className:"rounded-2xl",children:t.jsxs(f,{className:"p-5",children:[t.jsx("p",{className:"text-sm text-muted-foreground",children:"Crypto"}),t.jsx("p",{className:"mt-2 text-3xl font-semibold",children:ae})]})}),t.jsx(y,{className:"rounded-2xl",children:t.jsxs(f,{className:"p-5",children:[t.jsx("p",{className:"text-sm text-muted-foreground",children:"M-Pesa"}),t.jsx("p",{className:"mt-2 text-3xl font-semibold",children:se})]})}),t.jsx(y,{className:"rounded-2xl",children:t.jsxs(f,{className:"p-5",children:[t.jsx("p",{className:"text-sm text-muted-foreground",children:"Pending"}),t.jsx("p",{className:"mt-2 text-3xl font-semibold",children:Z})]})}),t.jsx(y,{className:"rounded-2xl sm:col-span-2 xl:col-span-4",children:t.jsxs(f,{className:"grid gap-4 p-5",children:[t.jsxs("div",{className:"grid gap-2 md:grid-cols-[1fr_220px]",children:[t.jsxs("div",{className:"grid gap-2",children:[t.jsx("label",{className:"text-sm font-medium",children:"Search"}),t.jsx(ve,{value:D,onChange:e=>H(e.target.value),placeholder:"Search by title, notes, status, or method"})]}),t.jsxs("div",{className:"grid gap-2",children:[t.jsx("label",{className:"text-sm font-medium",children:"Status"}),t.jsxs("select",{className:"h-10 rounded-md border border-input bg-background px-3 text-sm",value:A,onChange:e=>W(e.target.value),children:[t.jsx("option",{value:"all",children:"All statuses"}),t.jsx("option",{value:"unpaid",children:"Unpaid"}),t.jsx("option",{value:"pending",children:"Pending"}),t.jsx("option",{value:"paid",children:"Paid"}),t.jsx("option",{value:"failed",children:"Failed"})]})]})]}),t.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[t.jsx(x,{variant:S==="all"?"hero":"secondary",size:"sm",onClick:()=>F("all"),children:"All"}),t.jsx(x,{variant:S==="crypto"?"hero":"secondary",size:"sm",onClick:()=>F("crypto"),children:"Crypto"}),t.jsx(x,{variant:S==="mpesa"?"hero":"secondary",size:"sm",onClick:()=>F("mpesa"),children:"M-Pesa"}),t.jsxs("div",{className:"ml-auto text-sm text-muted-foreground",children:["Reviewed: ",t.jsx("span",{className:"font-medium text-foreground",children:ee+te})]})]}),t.jsxs("div",{className:"grid gap-2 md:grid-cols-2",children:[t.jsxs("div",{className:"grid gap-2",children:[t.jsx(K,{className:"text-sm font-medium",children:"Created From"}),t.jsx(B,{value:v,onChange:G,placeholder:"Any date"})]}),t.jsxs("div",{className:"grid gap-2",children:[t.jsx(K,{className:"text-sm font-medium",children:"Created To"}),t.jsx(B,{value:w,onChange:Q,placeholder:"Any date",minDate:v})]})]})]})})]}),z?t.jsxs("div",{className:"mb-6 flex items-center gap-3 rounded-2xl border border-destructive/30 bg-destructive/10 p-4 text-sm text-destructive",children:[t.jsx("span",{children:z}),t.jsx(x,{variant:"outline",size:"sm",onClick:()=>void k(),children:"Retry"})]}):null,t.jsxs("div",{className:"grid gap-4 md:grid-cols-2 xl:grid-cols-3",children:[N&&u.length===0?t.jsx(y,{className:"rounded-2xl md:col-span-2 xl:col-span-3",children:t.jsx(f,{className:"p-6 text-sm text-muted-foreground",children:"Loading crypto payments..."})}):null,!N&&u.length===0?t.jsx("div",{className:"md:col-span-2 xl:col-span-3",children:t.jsx(Ce,{icon:$e,title:"No crypto payments yet",description:"Once you submit a crypto-backed order, booking, or event registration, it will appear here."})}):null,b.map(e=>{var s;return t.jsxs(y,{className:"rounded-2xl",children:[t.jsx(me,{className:"border-b border-border pb-4",children:t.jsxs("div",{className:"flex items-start justify-between gap-3",children:[t.jsxs("div",{className:"min-w-0",children:[t.jsx(ue,{className:"text-base",children:e.title}),t.jsx("p",{className:"mt-1 text-sm text-muted-foreground",children:e.subtitle})]}),t.jsx(_,{variant:ke(e.paymentStatus),className:"capitalize",children:e.paymentStatus})]})}),t.jsxs(f,{className:"space-y-4 p-5",children:[t.jsxs("div",{className:"flex flex-wrap gap-2 text-xs text-muted-foreground",children:[t.jsx(_,{variant:"outline",className:"capitalize",children:e.kind.replaceAll("_"," ")}),t.jsx(_,{variant:Pe(e.paymentMethod),className:"capitalize",children:e.paymentMethod||"manual"}),t.jsx("span",{children:new Intl.NumberFormat("en-KE",{style:"currency",currency:"KES",maximumFractionDigits:0}).format(e.amountCents/100)})]}),t.jsx("div",{className:"text-xs text-muted-foreground",children:e.cryptoReviewNotes?e.cryptoReviewNotes:"No review notes yet."}),t.jsx("div",{className:"flex gap-2",children:e.paymentMethod==="crypto"?t.jsx(x,{variant:"hero",className:"w-full",onClick:()=>R(e),children:"Track Crypto Payment"}):t.jsxs("div",{className:"w-full rounded-xl border border-border bg-secondary/20 px-4 py-3 text-sm text-muted-foreground",children:["This payment is handled by ",((s=e.paymentMethod)==null?void 0:s.toUpperCase())||"manual"," and does not use the crypto timeline."]})}),t.jsx(x,{variant:"secondary",className:"w-full",onClick:()=>void le(e),children:e.kind==="order"?"Print Invoice":"Print Summary"})]})]},`${e.kind}-${e.id}`)}),!N&&u.length>0&&b.length===0?t.jsx(y,{className:"rounded-2xl md:col-span-2 xl:col-span-3",children:t.jsx(f,{className:"p-6 text-sm text-muted-foreground",children:"No payments match the current filters."})}):null]}),t.jsx(he,{open:!!d,onOpenChange:e=>{e||R(null)},children:t.jsxs(xe,{className:"max-h-[90vh] overflow-y-auto sm:max-w-3xl",children:[t.jsxs(ge,{children:[t.jsx(ye,{children:"Track Crypto Payment"}),t.jsx(fe,{children:"Follow the proof, blockchain explorer, and admin review timeline for this payment."})]}),t.jsx(ce,{title:d?d.title:"Crypto payment timeline",description:d?d.subtitle:void 0,resource:(j==null?void 0:j.resource)||null,transaction:(j==null?void 0:j.transaction)||null,loading:L,error:X,onRefresh:Y,refreshing:L})]})})]})})};export{Ze as default};
