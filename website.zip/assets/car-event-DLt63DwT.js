const e="/assets/car-event-BFuBplNv.jpg";export{e as c};
